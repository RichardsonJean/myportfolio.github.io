$( document ).ready(function() {
    $('#share').on('click', function(){
    $('#iconwrapper li').toggleClass('slideout');
  });
  
  });///end doc ready
  